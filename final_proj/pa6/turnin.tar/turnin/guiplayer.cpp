/*
#include "guiplayer.h"

using namespace std;


GUIPlayer( Player* p ) : PlayerGUI( p ) 
{
	
}
*/