#include <cstring>
#include <iostream>

#include "bankaccount.h"

using namespace std;

